# Convert-between-TFRecords-and-Images
A method of convert between tfrecords and images with TensorFlow and python.<br>
[my blog](http://blog.csdn.net/chaipp0607/article/details/72960028)   

